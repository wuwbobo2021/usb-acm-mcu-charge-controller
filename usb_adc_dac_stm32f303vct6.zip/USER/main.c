// by wuwbobo2021 <https://github.com/wuwbobo2021>, <wuwbobo@outlook.com>
// If you have found bugs in this program, please pull an issue, or contact me.

#include "usb_lib.h"
#include "usb_pwr.h"
#include "usb_desc.h"

#include "usb_adc_dac.h"

#define GPIO_ADC GPIOA
#define RCC_AHBPeriph_GPIO_ADC RCC_AHBPeriph_GPIOA
#define GPIO_Pin_ADC1 GPIO_Pin_1
#define GPIO_Pin_ADC2 GPIO_Pin_6
#define ADC1_Channel ADC_Channel_2 //PA1
#define ADC2_Channel ADC_Channel_3 //PA6

#define GPIO_DAC GPIOA
#define RCC_AHBPeriph_GPIO_DAC RCC_AHBPeriph_GPIOA
#define GPIO_Pin_DAC GPIO_Pin_4
#define DAC_Channel DAC_Channel_1

volatile uint32_t TickCount = 0, TimingDelay = 0; //SysTick
volatile uint32_t TickCount_ADC_Stop = 0;

volatile bool flag_iwdg = FALSE;
volatile bool flag_adc_channel_configured = FALSE, flag_adc_converting = FALSE;
volatile bool flag_bulk_ready = FALSE; uint8_t* ptr_buf_adc;
volatile bool flag_dac_stop_delay = FALSE; //used for the purpose of DAC zero output delay after stopping

volatile uint8_t buf_adc[ADC_Buffer_Size];

void SysTick_Init()
{
	// Setup SysTick Timer for 1 msec interrupts.
	// Reload Value = SysTick Counter Clock (Hz) x Desired Time base (s)
	// Reload Value should not exceed 0xFFFFFF

	SystemCoreClockUpdate(); //read system clock frequency
	if (SysTick_Config(SystemCoreClock / 1000)) //interval: 1 ms
		while (1); //Capture error 
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)SysTick_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void Delay(volatile uint32_t nTime)
{ 
  TimingDelay = nTime;
  while (TimingDelay > 0);
}

void SysTick_Handler(void)
{
	TickCount++;
	if (TimingDelay > 0) TimingDelay--;
}

void iwdg_init(void)
{
	IWDG_Enable();
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_256); //40kHz LSI / 256 = 156 Hz
	IWDG_SetReload(1600); //1s
	while (IWDG->SR != 0x00000000);
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Disable);
	IWDG_ReloadCounter();
}

void adc_calibrate(ADC_TypeDef* ADCx)
{
	ADC_VoltageRegulatorCmd(ADCx, ENABLE);
	Delay(10);
	ADC_SelectCalibrationMode(ADCx, ADC_CalibrationMode_Single);
	ADC_StartCalibration(ADCx);
	while (ADC_GetCalibrationStatus(ADCx) != RESET);
}

void adc_dma_init(void)
{
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIO_ADC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_ADC1 | GPIO_Pin_ADC2;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIO_ADC, &GPIO_InitStruct);

	ADC_DeInit(ADC1); //Reset ADC12
	RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div6); //12MHz
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC12 | RCC_AHBPeriph_DMA1, ENABLE);
	
	adc_calibrate(ADC1); adc_calibrate(ADC2);
	
	ADC_CommonInitTypeDef ADC_CommonInitStruct;
	ADC_CommonStructInit(&ADC_CommonInitStruct);
	ADC_CommonInitStruct.ADC_Mode = ADC_Mode_RegSimul; //ADC Dual Mode, regular simultaneous mode
	ADC_CommonInitStruct.ADC_Clock = ADC_Clock_AsynClkMode; //PLL->Prescaler->ADC, not from AHB HCLK
	ADC_CommonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_1; //DMA mode enabled for 12 and 10-bit resolution
	ADC_CommonInitStruct.ADC_DMAMode = ADC_DMAMode_Circular;
	ADC_CommonInitStruct.ADC_TwoSamplingDelay = 0;
	ADC_CommonInit(ADC1, &ADC_CommonInitStruct); //ADC1_2
	
	ADC_InitTypeDef ADC_InitStruct;
	ADC_StructInit(&ADC_InitStruct);
	ADC_InitStruct.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable; //continuous mode
	ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_AutoInjMode = ADC_AutoInjec_Disable;
	ADC_InitStruct.ADC_OverrunMode = ADC_OverrunMode_Enable; //don't preserve the old data
	ADC_InitStruct.ADC_NbrOfRegChannel = 1;
	ADC_Init(ADC1, &ADC_InitStruct); ADC_Init(ADC2, &ADC_InitStruct);
	
	ADC_DMACmd(ADC1, ENABLE);
	ADC_Cmd(ADC1, ENABLE); ADC_Cmd(ADC2, ENABLE);
	while (! (ADC_GetFlagStatus(ADC1, ADC_FLAG_RDY) && ADC_GetFlagStatus(ADC2, ADC_FLAG_RDY)));
	
	DMA_DeInit(DMA1_Channel1);
	DMA_InitTypeDef DMA_InitStruct;
	DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t) &(ADC1_2->CDR);
	DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t) buf_adc;
	DMA_InitStruct.DMA_BufferSize = ADC_Buffer_Data_Amount;
	DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStruct.DMA_Priority = DMA_Priority_High;
	DMA_Init(DMA1_Channel1, &DMA_InitStruct);
		
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)DMA1_Channel1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC | DMA_IT_HT, ENABLE); //half transfer, transfer complete
}

bool adc_channel_config(Cmd_ADC_Config* cmd_conf)
{
	if (! IS_ADC_SAMPLE_TIME(cmd_conf->ADC_SampleTime)) return FALSE;
	
	ADC_RegularChannelConfig(ADC1, ADC1_Channel, 1, cmd_conf->ADC_SampleTime);
	
	if (cmd_conf->Use_VRefInt_For_ADC2) {
		ADC_VrefintCmd(ADC2, ENABLE); //VRefInt:Channel18
		Delay(100);
		ADC_RegularChannelConfig(ADC2, ADC_Channel_18, 1, cmd_conf->ADC_SampleTime);
	} else {
		ADC_VrefintCmd(ADC2, DISABLE);
		ADC_RegularChannelConfig(ADC2, ADC2_Channel, 1, cmd_conf->ADC_SampleTime);
	}
	
	flag_adc_channel_configured = TRUE;
	return TRUE;
}

void dac_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	DAC_InitTypeDef DAC_InitStruct;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIO_DAC, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_DAC; //A4 DAC1_OUTPUT1
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIO_DAC, &GPIO_InitStruct);
	
	DAC_InitStruct.DAC_Trigger = DAC_Trigger_None;
	DAC_InitStruct.DAC_Buffer_Switch = DAC_BufferSwitch_Enable;
	DAC_InitStruct.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitStruct.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bits11_0;
	DAC_Init(DAC1, DAC_Channel, &DAC_InitStruct);
	
	DAC_Cmd(DAC1, DAC_Channel, ENABLE);
	Delay(10);
	
	DAC_SetChannel1Data(DAC1, DAC_Align_12b_R, 0x0000);
}

void resp_is_ok(bool ok)
{
	uint32_t reply[2] = {Cmd_Header};
	uint8_t* p_reply = (uint8_t*)&reply;
	p_reply[Cmd_Header_Length + 1 - 1] = (ok? Resp_OK : Resp_Failed);
	
	while (! packet_sent);
	CDC_Send_DATA((uint8_t*)&reply, Cmd_Header_Length + 1);
	while (! packet_sent){}; Delay(1);
}

void check_cmd(void)
{
	if (bDeviceState != CONFIGURED) return;
	
	CDC_Receive_DATA();
	if (Receive_length >= Cmd_Header_Length + 1) {
		if (*(uint32_t*)(Receive_Buffer) != Cmd_Header) {
			Receive_length = 0; return;
		}
		
		uint32_t check_reply = Resp_Check;
		uint16_t dac_val;
		
		switch (Receive_Buffer[Cmd_Header_Length + 1 - 1]) {
			case Cmd_ID_Check:
				resp_is_ok(TRUE); while (! packet_sent);
				CDC_Send_DATA((uint8_t*)&check_reply, sizeof(check_reply));
				break;
			
			case Cmd_ID_ADC_Config:
				if (Receive_length < Cmd_Header_Length + 1 + sizeof(Cmd_ADC_Config)) {
					resp_is_ok(FALSE); break;
				}
				resp_is_ok(adc_channel_config((Cmd_ADC_Config*)(Receive_Buffer + Cmd_Header_Length + 1)));
				if (flag_dac_stop_delay) TickCount_ADC_Stop = TickCount;
				if (flag_iwdg) IWDG_ReloadCounter();
				break;
			
			case Cmd_ID_ADC_Start:
				if (!flag_adc_channel_configured) {
					resp_is_ok(FALSE); break;
				}
				if (flag_adc_converting) {
					resp_is_ok(TRUE); break;
				}
				resp_is_ok(TRUE); Delay(500); //make sure the host can receive the response
				DMA_Cmd(DMA1_Channel1, ENABLE); ADC_StartConversion(ADC1);
				flag_adc_converting = TRUE; flag_dac_stop_delay = FALSE;
				if (! flag_iwdg) {
					iwdg_init(); flag_iwdg = TRUE;
				} else
					IWDG_ReloadCounter();
				break;
			
			case Cmd_ID_Shake:
				IWDG_ReloadCounter(); resp_is_ok(TRUE); break;
			
			case Cmd_ID_DAC_Output: //the only command that doesn't expect a response
				if (Receive_length < Cmd_Header_Length + 2) break;
				dac_val = *(uint16_t*)(Receive_Buffer + Cmd_Header_Length + 1);
				if (!flag_adc_converting && dac_val > 0) break;
				if (dac_val > 4095) break;
				
				if (flag_iwdg) IWDG_ReloadCounter();
				DAC_SetChannel1Data(DAC1, DAC_Align_12b_R, dac_val); break;
			
			case Cmd_ID_ADC_Stop:
				if (! flag_adc_converting) {
					resp_is_ok(TRUE); break;
				}
				// wait until DMA (half) transfer complete to avoid mixing of this incomplete
				// bulk of data with new data after it receives Cmd_ADC_Start for the next time.
				flag_bulk_ready = FALSE; while (! flag_bulk_ready);
				DMA_Cmd(DMA1_Channel1, DISABLE); ADC_StopConversion(ADC1);
				flag_adc_converting = FALSE; flag_bulk_ready = FALSE;
				flag_dac_stop_delay = TRUE; TickCount_ADC_Stop = TickCount;
				if (flag_iwdg) IWDG_ReloadCounter(); //unfortunately the IWDG cannot be stopped
				resp_is_ok(TRUE); break;
				
			case Cmd_ID_Reset:
				if (flag_adc_converting) {
					DMA_Cmd(DMA1_Channel1, DISABLE); ADC_StopConversion(ADC1);
					flag_adc_converting = FALSE;
				}
				DAC_SetChannel1Data(DAC1, DAC_Align_12b_R, 0x0000);
				resp_is_ok(TRUE);
				NVIC_SystemReset();
			
			default:
				resp_is_ok(FALSE); break;
		}
	}
	
	Receive_length = 0;
}

void usb_send_data(uint8_t* ptr, uint32_t sz)
{
	if (ptr == NULL || sz == 0) return;
	
	while (! packet_sent);
	
	uint32_t head = Data_Header;
	CDC_Send_DATA((uint8_t*)&head, Data_Header_Length);
	while (! packet_sent);
	
	while (sz >= VIRTUAL_COM_PORT_DATA_SIZE) {
		CDC_Send_DATA(ptr, VIRTUAL_COM_PORT_DATA_SIZE);
		while (! packet_sent);
		ptr += VIRTUAL_COM_PORT_DATA_SIZE;
		sz -= VIRTUAL_COM_PORT_DATA_SIZE;
	}
	
	CDC_Send_DATA(ptr, sz); //send an empty data pack at last if the previous pack is full-sized
	while (! packet_sent);
}

void DMA1_Channel1_IRQHandler(void) __attribute__ ((section (".ccmram")));
void DMA1_Channel1_IRQHandler(void)
{
	if (DMA_GetITStatus(DMA1_IT_HT1) != RESET) {
		ptr_buf_adc = (uint8_t*)buf_adc;
		flag_bulk_ready = TRUE;
		DMA_ClearITPendingBit(DMA1_IT_HT1); return;
	}
	
	if (DMA_GetITStatus(DMA1_IT_TC1) != RESET) {
		ptr_buf_adc = (uint8_t*)(buf_adc + ADC_Bulk_Size);
		flag_bulk_ready = TRUE;
		DMA_ClearITPendingBit(DMA1_IT_TC1); return;
	}
}

int main()
{
	SysTick_Init();
	dac_init();
	adc_dma_init();
	USB_Config();	
	
	while (1) {
		if (flag_adc_converting && flag_bulk_ready) {
			usb_send_data(ptr_buf_adc, ADC_Bulk_Size);
			flag_bulk_ready = FALSE;
		} else {
			if (flag_iwdg && !flag_adc_converting)
				IWDG_ReloadCounter();
			check_cmd();
			if (flag_dac_stop_delay && (uint32_t)(TickCount - TickCount_ADC_Stop) >= 5000) {
				DAC_SetChannel1Data(DAC1, DAC_Align_12b_R, 0x0000);
				flag_dac_stop_delay = FALSE;
			}
		}
	}
}
