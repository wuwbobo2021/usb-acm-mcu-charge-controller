// by wuwbobo2021 <https://github.com/wuwbobo2021>, <wuwbobo@outlook.com>
// If you have found bugs in this program, please pull an issue, or contact me.

#include "usb_lib.h"
#include "usb_pwr.h"
#include "usb_desc.h"

#include "comm_protocol.h"

#define ADDR_VREFINT_CAL ((uint16_t*) 0x1ffff7ba) //STM32F303xBC Reference Manual, 6.3.4

#define GPIO_ADC GPIOA
#define RCC_AHBPeriph_GPIO_ADC RCC_AHBPeriph_GPIOA
#define GPIO_Pin_ADC1 GPIO_Pin_1
#define GPIO_Pin_ADC2 GPIO_Pin_6
#define ADC1_Channel ADC_Channel_2    //PA1, Analog, No Pull
#define ADC2_Channel ADC_Channel_3    //PA6, Analog, No Pull

#define GPIO_DAC GPIOA
#define RCC_AHBPeriph_GPIO_DAC RCC_AHBPeriph_GPIOA
#define GPIO_Pin_DAC GPIO_Pin_4
#define DAC_Channel DAC_Channel_1     //PA4, Analog, No Pull

#define GPIO_EN GPIOA
#define RCC_AHBPeriph_GPIO_EN RCC_AHBPeriph_GPIOA
#define GPIO_Pin_EN GPIO_Pin_8        //PA8 (FT), AF (for TIM1), Open Drain, No Pull

// ADC data is double-buffered
#define ADC_Buffer_Data_Amount (48 * 128)
#define ADC_Buffer_Size (2 * 2 * ADC_Buffer_Data_Amount) //24,576 B
#define ADC_Bulk_Size (ADC_Buffer_Size / 2) //half buffer
#define ADC_Bulk_Data_Amount (ADC_Buffer_Data_Amount / 2)

Resp_Check hard_param;

volatile bool flag_lock = true;

volatile uint32_t delay_countdown = 0; volatile uint16_t shake_countdown = 0; 

// counter always >= duty_val (0), thus output is held at 0 (low)
const Cmd_PWM_DAC cmd_pwm_dac_disable_output =
	{.pwm_tim_prescaler = 0, .pwm_reload_val = 1, .pwm_duty_val = 0, .dac_val = 0};
Cmd_PWM_DAC cmd_pwm_dac;

volatile bool flag_adc_converting = false;
volatile bool flag_dma_single_mode = false; volatile uint16_t adc_bulk_interval = 0;
volatile bool flag_bulk_ready = false; uint8_t *volatile ptr_buf_adc = NULL;
uint8_t buf_adc[ADC_Buffer_Size];
volatile uint16_t ad_refint = 0;

void hard_param_init(void);

void systick_init(void);
void delay_ms(volatile uint32_t ms);
void iwdg_init(void);

void adc_calibrate(ADC_TypeDef* ADCx);
void adc_dma_init(void);
void adc_refint_init(void);
void adc_refint_read(void);
bool adc_start(Cmd_ADC_Start* cmd_start);
static inline void adc_stop(void);

void pwm_init(void);
void dac_init(void);
static inline bool pwm_dac_output(const Cmd_PWM_DAC* cmd_pwm_dac);
static inline void disable_output(void);

static inline void resp(CommResp* resp);
static inline void resp_is_ok(const CommCmd* cmd, bool ok);
void check_cmd(void);
void usb_send_data(uint8_t* ptr, uint32_t sz);

void SysTick_Handler(void);
void HardFault_Handler(void);
void DMA1_Channel1_IRQHandler(void);

int main()
{
	hard_param_init();
	
	systick_init(); iwdg_init();
	pwm_init(); dac_init(); disable_output();
	adc_refint_init(); adc_dma_init();
	USB_Config();
	
	while (true) {
		IWDG_ReloadCounter();
		check_cmd();
		
		if (flag_bulk_ready) {
			usb_send_data(ptr_buf_adc, ADC_Bulk_Size);
			flag_bulk_ready = false;
			adc_refint_read(); //for the next time
		}
		
		if (! flag_adc_converting)
			continue;
		else if (flag_lock && shake_countdown == 0)
			adc_stop();
		else if (flag_dma_single_mode && ptr_buf_adc) {
			// ptr_buf_adc is not NULL means the first half is already sent (above)
			delay_ms(adc_bulk_interval / 2); IWDG_ReloadCounter();
			if (flag_lock) disable_output(); //meet the protocol requirement in time
			adc_stop(); //reads the last bulk, it will be sent in the next loop
		}
	}
}

void hard_param_init()
{
	SystemCoreClockUpdate(); //read system clock frequency (Hz)
	
	CommResp resp = comm_resp(Cmd_ID_Check, Resp_OK);
	hard_param.resp = resp;
	hard_param.protocol_key = Protocol_Key;
	hard_param.dac_support = true;
	hard_param.pwm_clock_freq = 2 * SystemCoreClock;
	hard_param.adc_clock_freq = SystemCoreClock / 6;
	hard_param.adc_bulk_data_amount = ADC_Bulk_Data_Amount;
	hard_param.adc_vrefint = *ADDR_VREFINT_CAL * 3300.0 / ADC_Raw_Value_Max;
	
	uint16_t* opts = hard_param.adc_clock_cycles_opts;
	opts[ADC_SampleTime_1Cycles5] = 1.5 + 12.5;
	opts[ADC_SampleTime_2Cycles5] = 2.5 + 12.5;
	opts[ADC_SampleTime_4Cycles5] = 4.5 + 12.5;
	opts[ADC_SampleTime_7Cycles5] = 7.5 + 12.5;
	opts[ADC_SampleTime_19Cycles5] = 19.5 + 12.5;
	opts[ADC_SampleTime_61Cycles5] = 61.5 + 12.5;
	opts[ADC_SampleTime_181Cycles5] = 181.5 + 12.5;
	opts[ADC_SampleTime_601Cycles5] = 601.5 + 12.5;
	for (uint8_t i = 8; i < 16; i++) opts[i] = 0;
}

void systick_init()
{
	SystemCoreClockUpdate(); //read system clock frequency (Hz)
	
	// SysTick reload value (max: 0xffffff) is set for 1 ms interval
	if (SysTick_Config(SystemCoreClock / 1000)) 
		while (1); //Capture Error 
	
	// enable interruption
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)SysTick_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void delay_ms(volatile uint32_t ms)
{ 
  delay_countdown = ms;
  while (delay_countdown > 0);
}

void SysTick_Handler(void)
{
	if (delay_countdown > 0)
		delay_countdown--;
	if (shake_countdown > 0)
		shake_countdown--;
}

void iwdg_init(void)
{
	#ifdef DEBUG
		DBGMCU_APB1PeriphConfig(DBGMCU_IWDG_STOP, ENABLE);
	#endif
	IWDG_Enable();
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_256); //40kHz LSI / 256 = 156 Hz
	IWDG_SetReload(800); //5 s
	while (IWDG->SR != 0x00000000);
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Disable);
	IWDG_ReloadCounter();
}

void adc_calibrate(ADC_TypeDef* ADCx)
{
	ADC_VoltageRegulatorCmd(ADCx, ENABLE); delay_ms(10);
	ADC_SelectCalibrationMode(ADCx, ADC_CalibrationMode_Single);
	ADC_StartCalibration(ADCx);
	while (ADC_GetCalibrationStatus(ADCx) != RESET);
}

void adc_dma_init(void)
{
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIO_ADC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_ADC1 | GPIO_Pin_ADC2;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIO_ADC, &GPIO_InitStruct);

	ADC_DeInit(ADC1); //Reset ADC12
	RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div6); //12MHz
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC12 | RCC_AHBPeriph_DMA1, ENABLE);
	
	adc_calibrate(ADC1); adc_calibrate(ADC2);
	
	ADC_CommonInitTypeDef ADC_CommonInitStruct;
	ADC_CommonStructInit(&ADC_CommonInitStruct);
	ADC_CommonInitStruct.ADC_Mode = ADC_Mode_RegSimul; //ADC Dual Mode, regular simultaneous mode
	ADC_CommonInitStruct.ADC_Clock = ADC_Clock_AsynClkMode; //PLL->Prescaler->ADC, not from AHB HCLK
	ADC_CommonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_1; //DMA mode enabled for 12 and 10-bit resolution
	ADC_CommonInitStruct.ADC_DMAMode = ADC_DMAMode_Circular;
	ADC_CommonInitStruct.ADC_TwoSamplingDelay = 0;
	ADC_CommonInit(ADC1, &ADC_CommonInitStruct); //ADC1_2
	
	ADC_InitTypeDef ADC_InitStruct;
	ADC_StructInit(&ADC_InitStruct);
	ADC_InitStruct.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable; //continuous mode
	ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_AutoInjMode = ADC_AutoInjec_Disable;
	ADC_InitStruct.ADC_OverrunMode = ADC_OverrunMode_Enable; //don't preserve the old data
	ADC_InitStruct.ADC_NbrOfRegChannel = 1;
	ADC_Init(ADC1, &ADC_InitStruct); ADC_Init(ADC2, &ADC_InitStruct);
	
	ADC_DMACmd(ADC1, ENABLE);
	ADC_Cmd(ADC1, ENABLE); ADC_Cmd(ADC2, ENABLE);
	while (! (ADC_GetFlagStatus(ADC1, ADC_FLAG_RDY) && ADC_GetFlagStatus(ADC2, ADC_FLAG_RDY)));
	
	DMA_DeInit(DMA1_Channel1);
	DMA_InitTypeDef DMA_InitStruct;
	DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t) &(ADC1_2->CDR);
	DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t) buf_adc;
	DMA_InitStruct.DMA_BufferSize = ADC_Buffer_Data_Amount;
	DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStruct.DMA_Priority = DMA_Priority_High;
	DMA_Init(DMA1_Channel1, &DMA_InitStruct);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)DMA1_Channel1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	DMA_ITConfig(DMA1_Channel1, DMA_IT_TC | DMA_IT_HT, ENABLE); //half transfer, transfer complete
}

void adc_refint_init(void)
{
	ADC_DeInit(ADC3);
	
	RCC_ADCCLKConfig(RCC_ADC34PLLCLK_Div16); //4.5MHz
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC34, ENABLE);
	
	adc_calibrate(ADC3);
	
	ADC_InitTypeDef ADC_InitStruct;
	ADC_StructInit(&ADC_InitStruct);
	ADC_InitStruct.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Disable;
	ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_AutoInjMode = ADC_AutoInjec_Disable;
	ADC_InitStruct.ADC_OverrunMode = ADC_OverrunMode_Enable; //don't preserve the old data
	ADC_InitStruct.ADC_NbrOfRegChannel = 1;
	ADC_Init(ADC3, &ADC_InitStruct);
	
	ADC_Cmd(ADC3, ENABLE);
	while (! ADC_GetFlagStatus(ADC3, ADC_FLAG_RDY));
	
	ADC_VrefintCmd(ADC3, ENABLE);
	ADC_RegularChannelConfig(ADC3, ADC_Channel_18, 1, ADC_SampleTime_181Cycles5);
	adc_refint_read();
}

void adc_refint_read(void)
{
	ADC_StartConversion(ADC3);
	while (! ADC_GetFlagStatus(ADC3, ADC_FLAG_EOC));
	ad_refint = ADC_GetConversionValue(ADC3); //clears flag EOC
}

bool adc_start(Cmd_ADC_Start* cmd_start)
{
	if (flag_adc_converting) adc_stop();
	
	flag_dma_single_mode = cmd_start->discontinous_mode;
	adc_bulk_interval = adc_bulk_interval_ms(&hard_param, cmd_start->adc_clock_cycles_opt);
	
	adc_refint_read();
	
	ADC_RegularChannelConfig(ADC1, ADC1_Channel, 1, cmd_start->adc_clock_cycles_opt);
	ADC_RegularChannelConfig(ADC2, ADC2_Channel, 1, cmd_start->adc_clock_cycles_opt);
	DMA_SetCurrDataCounter(DMA1_Channel1, ADC_Buffer_Data_Amount);
	DMA_Cmd(DMA1_Channel1, ENABLE); ADC_StartConversion(ADC1); //start ADC1 and ADC2
	flag_adc_converting = true; ptr_buf_adc = NULL;
	
	if (flag_lock) {
		// try to keep 10 data before pwm_dac_output()
		float ms = adc_raw_data_interval_ms(&hard_param, cmd_start->adc_clock_cycles_opt);
		ms *= 10; delay_ms(ms);
		pwm_dac_output(&cmd_pwm_dac);
	}
	
	return true;
}

static inline void adc_stop(void)
{
	if (! flag_adc_converting) return;
	
	// wait until DMA (half) transfer complete to avoid mixing of this incomplete
	// bulk of data with new data after it receives Cmd_ADC_Start for the next time.
	// reference: RM0316, 13.4.3, page 265, 266 (Pointer Incrementation)
	flag_bulk_ready = false; while (! flag_bulk_ready);
	DMA1_Channel1->CCR &= ~DMA_CCR_EN; ADC_StopConversion(ADC1);
	
	if (flag_lock) disable_output();
	flag_adc_converting = false;
	if (! flag_dma_single_mode) flag_bulk_ready = false;
}

// TODO: do not start TIM1 when the expected output is low
void pwm_init(void)
{
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIO_EN, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_EN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIO_EN, &GPIO_InitStruct);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_6);
	
	RCC_TIMCLKConfig(RCC_TIM1CLK_PLLCLK); //2 * PLLCLK
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period = 0;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //unconcerned in this mode
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
	
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //enable
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable; //disable complementary output
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	TIM_Cmd(TIM1, ENABLE); //TIM1 Counter Enable
	TIM_CtrlPWMOutputs(TIM1, ENABLE); //TIM1 Main Output Enable
	
	cmd_pwm_dac = cmd_pwm_dac_disable_output;
}

void dac_init(void)
{
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIO_DAC, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_DAC;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIO_DAC, &GPIO_InitStruct);
	
	DAC_InitTypeDef DAC_InitStruct;
	DAC_InitStruct.DAC_Trigger = DAC_Trigger_None;
	DAC_InitStruct.DAC_Buffer_Switch = DAC_BufferSwitch_Enable;
	DAC_InitStruct.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitStruct.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bits11_0;
	DAC_Init(DAC1, DAC_Channel, &DAC_InitStruct);
	
	DAC_Cmd(DAC1, DAC_Channel, ENABLE); delay_ms(10);
}

static inline bool pwm_dac_output(const Cmd_PWM_DAC* cmd_pwm_dac)
{
	if (flag_lock && !flag_adc_converting
	&&  (cmd_pwm_dac->dac_val || cmd_pwm_dac->pwm_duty_val))
		return false;
	
	DAC1->DHR12R1 = cmd_pwm_dac->dac_val;
	
	TIM1->PSC = cmd_pwm_dac->pwm_tim_prescaler;
	if (cmd_pwm_dac->pwm_reload_val) {
		TIM1->ARR = cmd_pwm_dac->pwm_reload_val;
		TIM1->CCR1 = cmd_pwm_dac->pwm_duty_val;
	} else {
		TIM1->ARR = 1; // the output may not change if ARR is set to 0
		TIM1->CCR1 = (cmd_pwm_dac->pwm_duty_val? 2 : 0);
	}
	
	return true;
}

static inline void disable_output(void)
{
	pwm_dac_output(&cmd_pwm_dac_disable_output);
}

void check_cmd(void)
{
	if (bDeviceState != CONFIGURED) return; //USB is not configured
	if (! packet_receive) { //this flag is set by EP3_OUT_Callback (usb_endp.c)
		CDC_Receive_DATA(); return; //SetEPRxValid()
	}
	packet_receive = 0; //clear this flag
	
	// broken/multiple commands are not handled
	if (! is_valid_cmd((uint8_t*)Receive_Buffer, Receive_length)) {
		resp_is_ok(NULL, false); CDC_Receive_DATA(); return;
	}
	
	CommCmd* cmd = (CommCmd*)Receive_Buffer;
	bool suc = true;
	switch (cmd->cmd_id) {
		case Cmd_ID_Check:
			resp((CommResp*)&hard_param); break;
		
		case Cmd_ID_ADC_Start:
			suc = adc_start((Cmd_ADC_Start*)cmd);
			resp_is_ok(cmd, suc);
			shake_countdown = Shake_Interval_Max; break;
		
		case Cmd_ID_ADC_Stop:
			adc_stop(); resp_is_ok(cmd, true); break;
		
		case Cmd_ID_PWM_DAC:
			cmd_pwm_dac = *(Cmd_PWM_DAC*)cmd;
			if (flag_adc_converting || !flag_lock)
				suc = pwm_dac_output(&cmd_pwm_dac);
			if (! ((Cmd_PWM_DAC*)cmd)->no_resp)
				resp_is_ok(cmd, suc);
			shake_countdown = Shake_Interval_Max; break;
		
		case Cmd_ID_Disable_Output:
			disable_output(); resp_is_ok(cmd, true);
			shake_countdown = Shake_Interval_Max; break;
		
		case Cmd_ID_Shake:
			shake_countdown = Shake_Interval_Max;
			resp_is_ok(cmd, true); break;
		
		case Cmd_ID_Unlock:
			flag_lock = false;
			pwm_dac_output(&cmd_pwm_dac);
			resp_is_ok(cmd, true); break;
		
		case Cmd_ID_Reset:
			// FIXME: the host cannot reconnect to the device after this reset
			adc_stop(); resp_is_ok(cmd, true);
			PowerOff(); //USB reset (usb_pwr.h)
			NVIC_SystemReset();
		
		default: break; //never happen
	}
	
	CDC_Receive_DATA(); //SetEPRxValid()
}

static inline void resp(CommResp* resp)
{
	while (! packet_sent);
	CDC_Send_DATA((uint8_t*)resp, sizeof(CommResp) + resp->ext_length);
	while (! packet_sent);
}

static inline void resp_is_ok(const CommCmd* cmd, bool ok)
{
	uint8_t id = 0;
	if (cmd) id = cmd->cmd_id;
	CommResp r = comm_resp(id, ok? Resp_OK : Resp_Failed);
	resp(&r);
}

// TODO: enable bulk endpoint double buffering
void usb_send_data(uint8_t* ptr, uint32_t sz)
{
	if (ptr == NULL || sz == 0) return;
	
	while (! packet_sent);
	
	uint8_t head[Data_Header_Length + 2];
	*(uint32_t*)head = Data_Header;
	*(uint16_t*)(head + Data_Header_Length) = ad_refint;
	CDC_Send_DATA((uint8_t*)&head, Data_Header_Length + 2);
	while (! packet_sent);
	
	uint8_t l_send; bool last = false;
	while (true) {
		if (sz >= VIRTUAL_COM_PORT_DATA_SIZE)
			l_send = VIRTUAL_COM_PORT_DATA_SIZE;
		else {
			last = true; l_send = sz;
		}
		packet_sent = 0;
		UserToPMABufferCopy(ptr, ENDP1_TXADDR, l_send); //does nothing if l_send is 0
		_SetEPTxCount(ENDP1, l_send);
		_SetEPTxStatus(ENDP1, EP_TX_VALID)
		while (! packet_sent);
		
		if (last) break;
		ptr += VIRTUAL_COM_PORT_DATA_SIZE;
		sz -= VIRTUAL_COM_PORT_DATA_SIZE;
	}
}

void DMA1_Channel1_IRQHandler(void)
{
	if (DMA_GetITStatus(DMA1_IT_HT1) != RESET) {
		ptr_buf_adc = buf_adc;
		flag_bulk_ready = true;
		DMA_ClearITPendingBit(DMA1_IT_HT1); return;
	}
	
	if (DMA_GetITStatus(DMA1_IT_TC1) != RESET) {
		ptr_buf_adc = buf_adc + ADC_Bulk_Size;
		flag_bulk_ready = true;
		DMA_ClearITPendingBit(DMA1_IT_TC1); return;
	}
}

void HardFault_Handler(void)
{
	#ifndef DEBUG
		NVIC_SystemReset();
	#else
		while (true); //capture error
	#endif
}

